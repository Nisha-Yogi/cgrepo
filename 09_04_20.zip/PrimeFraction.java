import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class PrimeFraction {

	static List<Integer> fraction(int num){
		List<Integer> fractionList = new ArrayList<>();
		if(num>1) {
			for (int i = 2; i <= num; i++) {
				while (num % i == 0) {
					fractionList.add(i);
					num = num / i;
				}
			}
		}
		return fractionList;
	}

	public static void main(String[] args) {

		System.out.println("Enter a number");
		Scanner scanner = new Scanner(System.in);
		int num = Integer.parseInt(scanner.nextLine().trim());
		System.out.println(fraction(num));


	}

}
