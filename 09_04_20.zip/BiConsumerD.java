package org.cap.demo.funinter;

import java.util.function.BiConsumer;
import org.cap.model.UserDetails;

public class BiConsumerD {

	public static void main(String[] args) {
		
		BiConsumer<Integer,UserDetails> consume= (id,user) ->{
			System.out.println("userId : "+id+"user name : "+user.getUserName());
		};
		consume.accept(101,new UserDetails("userA","xxxx"));
		
	}

}
