import java.util.*;

public class Pangram {

	static boolean isPangram(String input) {
		
		boolean flag = false;
			if(input!=null) {
				ArrayList<String> alphabetList = new ArrayList<String>(Arrays.asList("abcdefghijklmnopqrstuvwxyz".split("")));
				String lowerStr = input.toLowerCase().trim().replaceAll(" ","");
				ArrayList<String> inputList = new ArrayList<String>(Arrays.asList(lowerStr.split("")));
				Collections.sort(inputList);
				if(inputList.containsAll(alphabetList)) {
					flag =true;
				}
		}
		return flag;
	}
	
	public static void main(String[] args) {
		
		System.out.println("Enter string");
		Scanner in = new Scanner(System.in);
        String input = "";
        input = in.nextLine();
		
		System.out.println(""+isPangram(input));

	}

}
