package org.cap.demo.funinter;


import java.util.function.BiFunction;
import org.cap.model.UserDetails;

public class BiFunctionD {

	public static void main(String[] args) {
		
		BiFunction<Integer,Integer,Integer> fn = (width,height) -> {
			int area =width*height; 
			return area;
		};
		
		System.out.println("Area of rectangel :"+fn.apply(20, 10));
		 
	}

}
