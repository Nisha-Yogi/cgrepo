package org.cap.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration
@EnableWebMvc
@ComponentScan(basePackages = {"org.cap"})
@EnableTransactionManagement //Declarative Transactions
public class MyWebConfig implements WebMvcConfigurer {

	
	@Bean
	public LocalEntityManagerFactoryBean getEntityManagerFactoryBean() {
		 LocalEntityManagerFactoryBean emf= new LocalEntityManagerFactoryBean();
		 	emf.setPersistenceUnitName("capg");
		 return emf;
	}
	
	
	@Bean
	public JpaTransactionManager getTransactionManager() {
		  JpaTransactionManager transactionManager=
				  new JpaTransactionManager(getEntityManagerFactoryBean().getObject());
		  return transactionManager;
	}
	
}
