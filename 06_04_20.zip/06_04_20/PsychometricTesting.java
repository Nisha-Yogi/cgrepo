import java.util.*;
import java.util.stream.Collectors;

public class PsychometricTesting {

    static void checkLimit(int[] items,int[] low,int[] up) {
        int[] count = new int[low.length];
        for(int i=0;i<low.length;i++) {
            int temp=0;
            int lowLimit = low[i];
            int upLimit = up[i];

            for(int item:items){
                if(lowLimit == upLimit && item <= upLimit){
                    temp++;
                }else {
                    if (item > lowLimit && item <= upLimit)
                        temp++;
                }
            }
            count[i]=temp;
        }
        List<Integer> list = Arrays.stream(count).boxed().collect(Collectors.toList());
        System.out.println("list : " + list);

    }

    public static void main(String[] args) {
        System.out.println("Enter no of elements , elements(split by space) , lower limit,  elements(split by space) , upper limit and  elements(split by space)");
        Scanner scanner = new Scanner(System.in);
        int arCount = Integer.parseInt(scanner.nextLine().trim());

        int[] ar = new int[arCount];

        String[] arItems = scanner.nextLine().split(" ");

        for (int arItr = 0; arItr < arCount; arItr++) {
            int arItem = Integer.parseInt(arItems[arItr].trim());
            ar[arItr] = arItem;
        }
        int lowLimit = Integer.parseInt(scanner.nextLine().trim());

        int[] lower = new int[lowLimit];

        String[] lowItems = scanner.nextLine().split(" ");

        for (int arItr = 0; arItr < lowLimit; arItr++) {
            int arItem = Integer.parseInt(lowItems[arItr].trim());
            lower[arItr] = arItem;
        }

        int upLimit = Integer.parseInt(scanner.nextLine().trim());

        int[] upper = new int[upLimit];

        String[] upItems = scanner.nextLine().split(" ");

        for (int arItr = 0; arItr < upLimit; arItr++) {
            int arItem = Integer.parseInt(upItems[arItr].trim());
            upper[arItr] = arItem;
        }
        checkLimit(ar,lower,upper);
    }
}