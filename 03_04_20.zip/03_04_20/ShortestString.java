import java.util.*;

public class ShortestString {
    static void checkString(String str) {
        Set<Character> uniqueSet = new HashSet<>();
        //find unique chars from str
        for(char c:str.toCharArray()){
            uniqueSet.add(c);
        }
        //System.out.println(uniqueSet);
        int len=0;
        int loopSize= uniqueSet.size();
        for(int i=0;i<str.length()-uniqueSet.size()+1;i++){
            List<Character> subList = new ArrayList<>();
            //find substr
            String subStr = str.substring(i,loopSize);
            for(char c:subStr.toCharArray()){
                subList.add(c);
            }
            //validate substring contains all unique chars
            if(subList.containsAll(uniqueSet)){
                len=subList.size();
            }
            loopSize++;
        }
        System.out.println(""+len);

    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input;
        input = in.next();
        checkString(input);
    }
}
