package org.cap.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@SequenceGenerator(name = "projectseq",initialValue = 101)
public class Project {

    @Id
    @GeneratedValue(generator = "projectseq",strategy = GenerationType.SEQUENCE)
    private int projectId;
    private String title;

    public Project( String title) {
        super();

        this.title = title;
    }

    public Project(int projectId, String title) {
        super();
        this.projectId = projectId;
        this.title = title;
    }

    public int getprojectId() {
        return projectId;
    }
    public void setprojectId(int projectId) {
        this.projectId = projectId;
    }
    public String gettitle() {
        return title;
    }
    public void settitle(String title) {
        this.title = title;
    }

}
