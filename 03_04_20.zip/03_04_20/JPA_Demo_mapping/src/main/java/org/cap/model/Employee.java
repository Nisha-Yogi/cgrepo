package org.cap.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Employee {
	@Id
	@GeneratedValue
	private int employeeId;
	private String employeeName;
	private double salary;
	
	//@OneToOne(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY)
	//@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	//@OneToOne(cascade = CascadeType.MERGE,fetch = FetchType.LAZY)
	@OneToOne(cascade = CascadeType.REMOVE,fetch = FetchType.LAZY)

	@JoinColumn(name = "address_fk")
	private Address address;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "companyid_fk")
	private Company company;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "projectid_fk")
	List<Project> projects = new ArrayList<>();

	public List<Project> getProjects() {
		return projects;
	}
	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}
	
	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	
	
	public Employee(String employeeName, double salary, Address address) {
		super();
		this.employeeName = employeeName;
		this.salary = salary;
		this.address = address;
	}

	public Employee(int employeeId, String employeeName, double salary, Address address) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.address = address;
	}

	public Employee() {
		super();
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary
				+ ", address=" + address + "]";
	}
	
	

}
